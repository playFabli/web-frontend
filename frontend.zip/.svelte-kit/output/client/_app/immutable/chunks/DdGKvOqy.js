import{lt as e}from"./A6qbuTk8.js";import{t}from"./D-XQlhUT.js";import"./DOcnNuEk2.js";import"./DoiFt_Ab2.js";var n=e({gaussianSplattingFragmentDeclarationWGSL:()=>a}),r=`gaussianSplattingFragmentDeclaration`,i=`fn gaussianColor(inColor: vec4f,inPosition: vec2f)->vec4f
{var A : f32=-dot(inPosition,inPosition);if (A>-4.0)
{var B: f32=exp(A)*inColor.a;
#include<logDepthFragment>
var color: vec3f=inColor.rgb;
#ifdef FOG
#include<fogFragment>
#endif
return vec4f(color,B);} else {return vec4f(0.0);}}
`;t.IncludesShadersStoreWGSL[r]||(t.IncludesShadersStoreWGSL[r]=i);var a={name:r,shader:i};export{n,a as t};
import{lt as e}from"./A6qbuTk8.js";import{t}from"./D-XQlhUT.js";import"./DJL3pvSn.js";import"./DdYHLUmD.js";var n=e({gaussianSplattingFragmentDeclaration:()=>a}),r=`gaussianSplattingFragmentDeclaration`,i=`vec4 gaussianColor(vec4 inColor)
{float A=-dot(vPosition,vPosition);if (A<-4.0) discard;float B=exp(A)*inColor.a;
#include<logDepthFragment>
vec3 color=inColor.rgb;
#ifdef FOG
#include<fogFragment>
#endif
return vec4(color,B);}
`;t.IncludesShadersStore[r]||(t.IncludesShadersStore[r]=i);var a={name:r,shader:i};export{n,a as t};
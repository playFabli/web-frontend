
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/(legal)" | "/(guest)" | "/(auth)" | "/(admin)" | "/" | "/(admin)/admin" | "/(admin)/admin/assets" | "/(admin)/admin/assets/create" | "/(admin)/admin/assets/[id]" | "/(admin)/admin/assets/[id]/edit" | "/(admin)/admin/logs" | "/(admin)/admin/users" | "/(admin)/admin/users/pending" | "/(admin)/admin/users/[id]" | "/(admin)/admin/users/[id]/ban" | "/(admin)/admin/users/[id]/edit" | "/(admin)/admin/user" | "/(admin)/admin/user/[id]" | "/(admin)/admin/user/[id]/verify-transaction" | "/(auth)/explore" | "/(auth)/explore/game" | "/(auth)/explore/game/create" | "/(auth)/explore/game/[id]" | "/(auth)/explore/game/[id]/editor" | "/(auth)/explore/game/[id]/play" | "/(auth)/forum" | "/(auth)/forum/create" | "/(auth)/forum/thread" | "/(auth)/forum/thread/[id]" | "/(legal)/legal" | "/(legal)/legal/privacy" | "/(legal)/legal/terms-of-service" | "/(auth)/marketplace" | "/(auth)/marketplace/item" | "/(auth)/marketplace/item/create" | "/(auth)/marketplace/item/[id]" | "/(auth)/marketplace/item/[id]/edit" | "/(auth)/petitions" | "/(auth)/roadmap" | "/(auth)/users" | "/(guest)/user" | "/(auth)/user" | "/(auth)/user/avatar" | "/(auth)/user/banned" | "/(guest)/user/forgot-password" | "/(auth)/user/friends" | "/(auth)/user/friends/[id]" | "/(auth)/user/homepage" | "/(auth)/user/inventory" | "/(auth)/user/inventory/my" | "/(auth)/user/inventory/[id]" | "/(auth)/user/leaderboard" | "/(guest)/user/login" | "/(auth)/user/profile" | "/(auth)/user/profile/[id]" | "/(guest)/user/register" | "/(guest)/user/reset-password" | "/(auth)/user/settings" | "/(auth)/user/trades" | "/(auth)/user/trades/create" | "/(auth)/user/trades/create/[id]" | "/(auth)/user/transactions" | "/(auth)/user/upgrade";
		RouteParams(): {
			"/(admin)/admin/assets/[id]": { id: string };
			"/(admin)/admin/assets/[id]/edit": { id: string };
			"/(admin)/admin/users/[id]": { id: string };
			"/(admin)/admin/users/[id]/ban": { id: string };
			"/(admin)/admin/users/[id]/edit": { id: string };
			"/(admin)/admin/user/[id]": { id: string };
			"/(admin)/admin/user/[id]/verify-transaction": { id: string };
			"/(auth)/explore/game/[id]": { id: string };
			"/(auth)/explore/game/[id]/editor": { id: string };
			"/(auth)/explore/game/[id]/play": { id: string };
			"/(auth)/forum/thread/[id]": { id: string };
			"/(auth)/marketplace/item/[id]": { id: string };
			"/(auth)/marketplace/item/[id]/edit": { id: string };
			"/(auth)/user/friends/[id]": { id: string };
			"/(auth)/user/inventory/[id]": { id: string };
			"/(auth)/user/profile/[id]": { id: string };
			"/(auth)/user/trades/create/[id]": { id: string }
		};
		LayoutParams(): {
			"/(legal)": Record<string, never>;
			"/(guest)": Record<string, never>;
			"/(auth)": { id?: string | undefined };
			"/(admin)": { id?: string | undefined };
			"/": { id?: string | undefined };
			"/(admin)/admin": { id?: string | undefined };
			"/(admin)/admin/assets": { id?: string | undefined };
			"/(admin)/admin/assets/create": Record<string, never>;
			"/(admin)/admin/assets/[id]": { id: string };
			"/(admin)/admin/assets/[id]/edit": { id: string };
			"/(admin)/admin/logs": Record<string, never>;
			"/(admin)/admin/users": { id?: string | undefined };
			"/(admin)/admin/users/pending": Record<string, never>;
			"/(admin)/admin/users/[id]": { id: string };
			"/(admin)/admin/users/[id]/ban": { id: string };
			"/(admin)/admin/users/[id]/edit": { id: string };
			"/(admin)/admin/user": { id?: string | undefined };
			"/(admin)/admin/user/[id]": { id: string };
			"/(admin)/admin/user/[id]/verify-transaction": { id: string };
			"/(auth)/explore": { id?: string | undefined };
			"/(auth)/explore/game": { id?: string | undefined };
			"/(auth)/explore/game/create": Record<string, never>;
			"/(auth)/explore/game/[id]": { id: string };
			"/(auth)/explore/game/[id]/editor": { id: string };
			"/(auth)/explore/game/[id]/play": { id: string };
			"/(auth)/forum": { id?: string | undefined };
			"/(auth)/forum/create": Record<string, never>;
			"/(auth)/forum/thread": { id?: string | undefined };
			"/(auth)/forum/thread/[id]": { id: string };
			"/(legal)/legal": Record<string, never>;
			"/(legal)/legal/privacy": Record<string, never>;
			"/(legal)/legal/terms-of-service": Record<string, never>;
			"/(auth)/marketplace": { id?: string | undefined };
			"/(auth)/marketplace/item": { id?: string | undefined };
			"/(auth)/marketplace/item/create": Record<string, never>;
			"/(auth)/marketplace/item/[id]": { id: string };
			"/(auth)/marketplace/item/[id]/edit": { id: string };
			"/(auth)/petitions": Record<string, never>;
			"/(auth)/roadmap": Record<string, never>;
			"/(auth)/users": Record<string, never>;
			"/(guest)/user": Record<string, never>;
			"/(auth)/user": { id?: string | undefined };
			"/(auth)/user/avatar": Record<string, never>;
			"/(auth)/user/banned": Record<string, never>;
			"/(guest)/user/forgot-password": Record<string, never>;
			"/(auth)/user/friends": { id?: string | undefined };
			"/(auth)/user/friends/[id]": { id: string };
			"/(auth)/user/homepage": Record<string, never>;
			"/(auth)/user/inventory": { id?: string | undefined };
			"/(auth)/user/inventory/my": Record<string, never>;
			"/(auth)/user/inventory/[id]": { id: string };
			"/(auth)/user/leaderboard": Record<string, never>;
			"/(guest)/user/login": Record<string, never>;
			"/(auth)/user/profile": { id?: string | undefined };
			"/(auth)/user/profile/[id]": { id: string };
			"/(guest)/user/register": Record<string, never>;
			"/(guest)/user/reset-password": Record<string, never>;
			"/(auth)/user/settings": Record<string, never>;
			"/(auth)/user/trades": { id?: string | undefined };
			"/(auth)/user/trades/create": { id?: string | undefined };
			"/(auth)/user/trades/create/[id]": { id: string };
			"/(auth)/user/transactions": Record<string, never>;
			"/(auth)/user/upgrade": Record<string, never>
		};
		Pathname(): "/" | "/admin" | "/admin/assets" | "/admin/assets/create" | `/admin/assets/${string}/edit` & {} | "/admin/logs" | "/admin/users" | "/admin/users/pending" | `/admin/users/${string}/ban` & {} | `/admin/users/${string}/edit` & {} | `/admin/user/${string}/verify-transaction` & {} | "/explore" | "/explore/game/create" | `/explore/game/${string}` & {} | `/explore/game/${string}/editor` & {} | `/explore/game/${string}/play` & {} | "/forum" | "/forum/create" | `/forum/thread/${string}` & {} | "/legal/privacy" | "/legal/terms-of-service" | "/marketplace" | "/marketplace/item/create" | `/marketplace/item/${string}` & {} | `/marketplace/item/${string}/edit` & {} | "/petitions" | "/roadmap" | "/users" | "/user/avatar" | "/user/banned" | "/user/forgot-password" | `/user/friends/${string}` & {} | "/user/homepage" | "/user/inventory/my" | `/user/inventory/${string}` & {} | "/user/leaderboard" | "/user/login" | `/user/profile/${string}` & {} | "/user/register" | "/user/reset-password" | "/user/settings" | "/user/trades" | `/user/trades/create/${string}` & {} | "/user/transactions" | "/user/upgrade";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/avatar.png" | "/badges/FounderBadge.png" | "/favicon.ico" | "/logo.png" | "/logo_full.png" | "/robots.txt" | "/templates/TemplatePants.png" | "/templates/TemplateShirt.png" | string & {};
	}
}
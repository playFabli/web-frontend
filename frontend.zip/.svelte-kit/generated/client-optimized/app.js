// in dev, this makes Vite inject its client as this module's first dependency,
// so that global constant replacements are installed before any other module
// (including user hooks) evaluates. In build it's inert.
import.meta.hot;




export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22'),
	() => import('./nodes/23'),
	() => import('./nodes/24'),
	() => import('./nodes/25'),
	() => import('./nodes/26'),
	() => import('./nodes/27'),
	() => import('./nodes/28'),
	() => import('./nodes/29'),
	() => import('./nodes/30'),
	() => import('./nodes/31'),
	() => import('./nodes/32'),
	() => import('./nodes/33'),
	() => import('./nodes/34'),
	() => import('./nodes/35'),
	() => import('./nodes/36'),
	() => import('./nodes/37'),
	() => import('./nodes/38'),
	() => import('./nodes/39'),
	() => import('./nodes/40'),
	() => import('./nodes/41'),
	() => import('./nodes/42'),
	() => import('./nodes/43'),
	() => import('./nodes/44'),
	() => import('./nodes/45'),
	() => import('./nodes/46'),
	() => import('./nodes/47'),
	() => import('./nodes/48'),
	() => import('./nodes/49'),
	() => import('./nodes/50')
];

export const server_loads = [4,2,3];

export const dictionary = {
		"/(guest)": [~44,[4]],
		"/(admin)/admin": [~6,[2]],
		"/(admin)/admin/assets": [~7,[2]],
		"/(admin)/admin/assets/create": [~8,[2]],
		"/(admin)/admin/assets/[id]/edit": [~9,[2]],
		"/(admin)/admin/logs": [~10,[2]],
		"/(admin)/admin/users": [~12,[2]],
		"/(admin)/admin/users/pending": [~13,[2]],
		"/(admin)/admin/users/[id]/ban": [~14,[2]],
		"/(admin)/admin/users/[id]/edit": [~15,[2]],
		"/(admin)/admin/user/[id]/verify-transaction": [~11,[2]],
		"/(auth)/explore": [~16,[3]],
		"/(auth)/explore/game/create": [17,[3]],
		"/(auth)/explore/game/[id]": [~18,[3]],
		"/(auth)/explore/game/[id]/editor": [19,[3]],
		"/(auth)/explore/game/[id]/play": [20,[3]],
		"/(auth)/forum": [~21,[3]],
		"/(auth)/forum/create": [~22,[3]],
		"/(auth)/forum/thread/[id]": [~23,[3]],
		"/(legal)/legal/privacy": [49,[5]],
		"/(legal)/legal/terms-of-service": [50,[5]],
		"/(auth)/marketplace": [~24,[3]],
		"/(auth)/marketplace/item/create": [~25,[3]],
		"/(auth)/marketplace/item/[id]": [~26,[3]],
		"/(auth)/marketplace/item/[id]/edit": [~27,[3]],
		"/(auth)/petitions": [28,[3]],
		"/(auth)/roadmap": [29,[3]],
		"/(auth)/users": [43,[3]],
		"/(auth)/user/avatar": [~30,[3]],
		"/(auth)/user/banned": [31,[3]],
		"/(guest)/user/forgot-password": [45,[4]],
		"/(auth)/user/friends/[id]": [~32,[3]],
		"/(auth)/user/homepage": [~33,[3]],
		"/(auth)/user/inventory/my": [~34,[3]],
		"/(auth)/user/inventory/[id]": [~35,[3]],
		"/(auth)/user/leaderboard": [~36,[3]],
		"/(guest)/user/login": [46,[4]],
		"/(auth)/user/profile/[id]": [~37,[3]],
		"/(guest)/user/register": [47,[4]],
		"/(guest)/user/reset-password": [~48,[4]],
		"/(auth)/user/settings": [~38,[3]],
		"/(auth)/user/trades": [~39,[3]],
		"/(auth)/user/trades/create/[id]": [~40,[3]],
		"/(auth)/user/transactions": [~41,[3]],
		"/(auth)/user/upgrade": [42,[3]]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));
export const encoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.encode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';

export const get_error_template = () => import('../shared/error-template.js').then(m => m.default);